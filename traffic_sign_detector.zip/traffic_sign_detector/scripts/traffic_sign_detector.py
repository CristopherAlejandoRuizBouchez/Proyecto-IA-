#!/usr/bin/env python3
import cv2
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from tensorflow.keras.models import load_model
import numpy as np
from geometry_msgs.msg import Twist
import os

class TrafficSignDetector:
    def __init__(self):
        rospy.init_node('traffic_sign_detector')
        self.bridge = CvBridge()

        # Variables para estado y velocidad
        self.estado = None
        self.velocidad = 1.0

        # Cargar el modelo desde la ruta relativa
        model_path = os.path.join(os.path.dirname(__file__), 'traffic_sign_transfer_model.h5')
        rospy.loginfo("Cargando modelo...")
        self.model = load_model(model_path)
        rospy.loginfo("Modelo cargado")

        # Suscribirse al tópico de imagen de la cámara frontal
        self.image_sub = rospy.Subscriber('/catvehicle/camera_front/image_raw_front', Image, self.callback, queue_size=3)

        # Publicador para la velocidad
        self.cmd_pub = rospy.Publisher('/catvehicle/cmd_vel_safe', Twist, queue_size=1)

        # Temporizador para publicar la velocidad a 100Hz (cada 10ms)
        self.timer = rospy.Timer(rospy.Duration(0.015), self.publish_velocity)

    def preprocess(self, img):
        # Redimensionar la imagen al tamaño usado en el entrenamiento
        img = cv2.resize(img, (128, 128))
        # Convertir a float32 y reescalar al rango [0, 1], como en ImageDataGenerator
        img = img.astype('float32') / 255.0
        # Asegurar el formato (64, 64, 3), necesario si la imagen tiene menos canales
        if img.shape[-1] != 3:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        # Expandir dimensiones para cumplir con el formato de entrada del modelo
        img = np.expand_dims(img, axis=0)
        return img

    def callback(self, data):
        # Procesar la imagen
        cv_image = self.bridge.imgmsg_to_cv2(data, 'bgr8')
        processed_img = self.preprocess(cv_image)
        prediction = np.argmax(self.model.predict(processed_img))
        rospy.loginfo(f"velocidad:  {self.velocidad}")
        rospy.loginfo(f"Predicción: {prediction}")
        if prediction != self.estado:
            self.update_state(prediction)

    def update_state(self, new_state):
        rospy.loginfo(f"Cambio de estado detectado: {self.estado} -> {new_state}")
        self.estado = new_state
        self.set_velocity_based_on_state()

    def set_velocity_based_on_state(self):
        if self.estado == 1:  # STOP
            rospy.loginfo("STOP - Deteniendo robot")
            self.velocidad = 0.0
            self.publish_immediate_stop()
        elif self.estado == 0:  # Velocidad alta
            rospy.loginfo("Velocidad alta")
            self.velocidad = 5.0
        elif self.estado == 2:  # Velocidad baja
            rospy.loginfo("Velocidad baja")
            self.velocidad = 2.5

    def publish_immediate_stop(self):
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.cmd_pub.publish(twist)
        rospy.sleep(15)  # Detener por 15 segundos
        self.velocidad = 0.2  # Reanudar velocidad baja por defecto

    def publish_velocity(self, event=None):
        twist = Twist()
        twist.linear.x = self.velocidad
        twist.angular.z = 0.0
        self.cmd_pub.publish(twist)

if __name__ == '__main__':
    TrafficSignDetector()
    rospy.spin()