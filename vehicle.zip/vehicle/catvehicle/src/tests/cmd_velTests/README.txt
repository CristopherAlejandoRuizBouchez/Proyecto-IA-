Author: Jonathan Sprinkle

Sends cmd_vel message tests. These tests will only run correctly when
the cmdvel2gazebo node is running.

