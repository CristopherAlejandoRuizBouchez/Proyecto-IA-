import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import os

# Configuración
image_size = (128, 128)  # Aumentar el tamaño para MobileNetV2
batch_size = 32
epochs = 20
dataset_dir = 'dataset'  # Ruta al directorio con tus imágenes

# Verificar si la carpeta dataset existe
if not os.path.exists(dataset_dir):
    raise FileNotFoundError(f"No se encontró la carpeta '{dataset_dir}'")

# Crear el generador de datos con aumentos
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=30,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest',
    validation_split=0.2  # 20% de las imágenes para validación
)

train_generator = train_datagen.flow_from_directory(
    dataset_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='sparse',  # Etiquetas numéricas
    subset='training'
)

validation_generator = train_datagen.flow_from_directory(
    dataset_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='sparse',
    subset='validation'
)

# Verificar las etiquetas asignadas a cada clase
print("Etiquetas asignadas:", train_generator.class_indices)

# Cargar MobileNetV2 preentrenado
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(128, 128, 3))

# Congelar las capas del modelo base
base_model.trainable = False

# Crear el modelo completo
model = Sequential([
    base_model,
    GlobalAveragePooling2D(),  # Reducir la dimensionalidad
    Dense(128, activation='relu'),  # Capa densa intermedia
    Dropout(0.5),  # Evitar sobreajuste
    Dense(3, activation='softmax')  # Tres clases de salida
])

# Compilar el modelo
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Entrenar el modelo
model.fit(train_generator, 
          epochs=epochs, 
          validation_data=validation_generator)

# Guardar el modelo entrenado
model.save('traffic_sign_transfer_model.h5')

print("Modelo entrenado y guardado como 'traffic_sign_transfer_model.h5'")
